Create table Patients(
Patient_id NUMBER(3),
Patient_name VARCHAR(10) NOT NULL,
Patient_Email VARCHAR(10) UNIQUE,
Patient_regDate DATE);

Create table Medicines(
Medicine_id NUMBER(3),
Medicine_name VARCHAR(10) NOT NULL
);

Create table Prescriptions(
Prescription_id NUMBER(3),
Prescription_date DATE,
Patient_id   NUMBER(3));

Create table Prescription_Medicines(
id NUMBER(3),
Medicine_id NUMBER(3),
Prescription_id NUMBER(3));

Alter Table Patients 
add Constraint pk_pid Primary key(Patient_id);

Alter Table Medicines 
add Constraint mk_pid Primary key(Medicine_id);

Alter Table Prescriptions
add Constraint prk_pid Primary key(Prescription_id);

Alter Table Prescription_Medicines
add Constraint prmk_pid Primary key(id);

Alter Table Prescriptions
add foreign key(Patient_id)
references Patients(Patient_id);

Alter Table Medicines
add foreign key(Medicine_id)
references Prescription_Medicines(Medicine_id);

Alter Table Prescriptions
add foreign key(Prescription_id)
references Prescription_Medicines(Prescription_id);

Insert into Patients
values(1,'XYZ','X@mail.com',SYSDATE);
Insert into Patients
values(2,'ABC','A@mail.com',SYSDATE);
Insert into Patients
values(3,'IJK','I@mail.com',SYSDATE);

Insert into Medicines
values(1,'Med1');
Insert into Medicines
values(2,'Med2');
Insert into Medicines
values(3,'Med3');
Insert into Medicines
values(4,'Med4');
Insert into Medicines
values(5,'Med5');

Insert into Prescription_Medicines
values(1,1,1);
Insert into Prescription_Medicines
values(2,2,2);
Insert into Prescription_Medicines
values(3,3,3);


Insert into Prescriptions
values(1,'27-JAN-2011',3);
Insert into Prescriptions
values(2,'22-JUL-2011',1);
Insert into Prescriptions
values(3,'26-DEC-2011',2);


Select * from Patients where patient_regdate between '28-NOV-2019' and '29-DEC-2019';

--Print the prescription details including all the medicines for a given patient 
select * from Prescriptions p join Prescription_Medicines pm on p.Prescription_id=pm.Prescription_id;