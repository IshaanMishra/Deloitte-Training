
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import oracle.jdbc.driver.OracleDriver;

public class Patient {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		createPatientDetails();
	}

	static void createPatientDetails() {
		
		Driver d=new OracleDriver();
		Connection conn = null;
			try {
				DriverManager.registerDriver(d);
				String userName="hr";
				String password="hr";
				String url="jdbc:oracle:thin:@192.168.1.41:1522:xe";
				
				//Establish the connection
				System.out.println("Connecting to Oracle Database.....");
				
				conn=DriverManager.getConnection(url,userName,password);
				conn.setAutoCommit(false);
				System.out.println("Oracle Database Connected");
				

				String insQuery="Insert into Patients Values(?,?,?,to_date(?, 'yyyy-mm-dd'))";
				String selQuery="Select * from Patients";
				

				
				PreparedStatement pstmt2=conn.prepareStatement(insQuery);
				PreparedStatement pstmt=conn.prepareStatement(selQuery);
			
				pstmt2.setInt(1,6);
				pstmt2.setString(2,"MNO");
				pstmt2.setString(3, "M@mail.com");
				pstmt2.setDate(4, new java.sql.Date(new java.util.Date().getTime()));
				
				ResultSet rs2=pstmt2.executeQuery();	
				
		
				ResultSet rs=pstmt.executeQuery();
			
	
				while(rs.next()) {
					System.out.format("%32s%20s%16s%16s",rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4));
					System.out.println();
				}	
				
				
				conn.commit();
				conn.close();
				System.out.println("Closing the databse connection");
				
			} catch (SQLException e) {
				try {
					conn.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.err.println("Error in registering the driver");
				e.printStackTrace();
			}
			
		
		
	}
	
}

