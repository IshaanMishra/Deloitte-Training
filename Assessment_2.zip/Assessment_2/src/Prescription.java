

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import oracle.jdbc.driver.OracleDriver;

public class Prescription {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		createPrescriptionDetails();
	}

	static void createPrescriptionDetails() {
		
		Driver d=new OracleDriver();
		Connection conn = null;
			try {
				DriverManager.registerDriver(d);
				String userName="hr";
				String password="hr";
				String url="jdbc:oracle:thin:@192.168.1.41:1522:xe";
				
				//Establish the connection
				System.out.println("Connecting to Oracle Database.....");
				
				conn=DriverManager.getConnection(url,userName,password);
				conn.setAutoCommit(false);
				System.out.println("Oracle Database Connected");
				
				
				String insQuery="Insert into Prescriptions Values(?,to_date(?, 'yyyy-mm-dd'),?,?)";
				String selQuery="Select * from Prescriptions";
				
				
				PreparedStatement pstmt2=conn.prepareStatement(insQuery);
				PreparedStatement pstmt=conn.prepareStatement(selQuery);
				
				
				pstmt2.setInt(1,1);
				pstmt2.setDate(2, new java.sql.Date(new java.util.Date().getTime()));
				pstmt2.setInt(3,1);
				pstmt2.setString(4, "Medicine");
				
				
				ResultSet rs2=pstmt2.executeQuery();					
		
				ResultSet rs=pstmt.executeQuery();
			
				
				while(rs.next()) {
					System.out.format("%32s%20s%16s%16s",rs.getInt(1),rs.getDate(2),rs.getInt(3),rs.getString(4));
					System.out.println();
				}	
				
				
				conn.commit();
				conn.close();
				System.out.println("Closing the databse connection");
				
			} catch (SQLException e) {
				try {
					conn.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.err.println("Error in registering the driver");
				e.printStackTrace();
			}
			
		
	}
	
}


