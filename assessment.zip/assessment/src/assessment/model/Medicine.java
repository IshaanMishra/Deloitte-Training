package assessment.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Medicines")
public class Medicine {

	private int id;
	
	private String name;
	
	Medicine(){}

	public Medicine(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}


	public int getid() {
		return id;
	}


	public void setid(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Medicine [id=" + id + ", name=" + name + "]";
	}
		
	
}
