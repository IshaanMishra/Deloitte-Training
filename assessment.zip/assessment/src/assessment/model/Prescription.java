package assessment.model;

import java.util.Arrays;
import java.util.Date;

public class Prescription {

	
	private int id;
	
	private Date date;
	
	private String patient;
	
	private String[] medicines;
	
	Prescription(){}

	public Prescription(int id, Date date, String patient, String[] medicines) {
		super();
		this.id = id;
		this.date = date;
		this.patient = patient;
		this.medicines = medicines;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getPatient() {
		return patient;
	}

	public void setPatient(String patient) {
		this.patient = patient;
	}

	public String[] getMedicines() {
		return medicines;
	}

	public void setMedicines(String[] medicines) {
		this.medicines = medicines;
	}

	@Override
	public String toString() {
		return "Prescription [id=" + id + ", date=" + date + ", patient=" + patient + ", medicines="
				+ Arrays.toString(medicines) + "]";
	}

	
	
	
}
