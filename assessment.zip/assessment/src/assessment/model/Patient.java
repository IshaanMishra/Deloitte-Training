package assessment.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Patients")
public class Patient {

	@Id
	
	private int id;
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="REGDATE")
	private Date date;
	
	Patient(){}

	public Patient(int id, String name, String email, Date date) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.date = date;
	}


	public int getPatientId() {
		return id;
	}

	public void setPatientId(int patientId) {
		this.id = patientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getRegDate() {
		return date;
	}

	public void setRegDate(Date regDate) {
		this.date = regDate;
	}
	

	@Override
	public String toString() {
		return "Patient [patientId=" + id + ", name=" + name + ", email=" + email + ", regDate=" + date + "]";
	}
	
}
